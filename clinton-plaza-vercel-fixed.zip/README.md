# Clinton Plaza Website

A simple leasing and tenant showcase site for Clinton Plaza Shopping Center built with Next.js.